<?php
if (!defined('EVENT_ESPRESSO_VERSION'))
	exit('No direct script access allowed');

/**
 * Event Espresso
 *
 * Event Registration and Management Plugin for WordPress
 *
 * @ package			Event Espresso
 * @ author				Udenewu Kingsley
 * @ copyright		(c) 2015 Voguepay  All Rights Reserved.
 * @ license			http://eventespresso.com/support/terms-conditions/   * see Plugin Licensing *
 * @ link					https://www.voguepay.com
 * @ version		 	1.0
 *
 * ------------------------------------------------------------------------
 *
 * Payment Gateway - VoguePay
 *
 * @package			Event Espresso
 * @subpackage		gateways/
 * @author			Udenewu Kingsley
 * ------------------------------------------------------------------------
 */
Class EE_Voguepay extends EE_Offsite_Gateway {

	private static $_instance = NULL;

	public static function instance(EEM_Gateways &$model) {
		// check if class object is instantiated
		if (self::$_instance === NULL or !is_object(self::$_instance) or ! ( self::$_instance instanceof  EE_Voguepay )) {
			self::$_instance = new self($model);
			//echo '<h3>'. __CLASS__ .'->'.__FUNCTION__.'  ( line no: ' . __LINE__ . ' )</h3>';
		}
		return self::$_instance;
	}

	protected function __construct(EEM_Gateways &$model) {
		$this->_gateway_name = 'Voguepay';
		$this->_button_base = 'logo.png';
		$this->_path = str_replace('\\', '/', __FILE__);

		$this->addField('rm', '2');		 // Return method = POST
		$this->addField('cmd', '_xclick');
		parent::__construct($model);
		
		$this->_gatewayUrl = 'https://voguepay.com/pay';

		
	}

	

	protected function _default_settings() {
		$this->_payment_settings['merchant_id'] = '';
		$this->_payment_settings['memo'] = '';
		
		$this->_payment_settings['display_name'] = __('Voguepay','event_espresso');
		$this->_payment_settings['current_path'] = '';
		$this->_payment_settings['button_url'] = $this->_btn_img;

	}

	protected function _update_settings() {
		$this->_payment_settings['merchant_id'] = $_POST['v_merchant_id'];
		$this->_payment_settings['memo'] = $_POST['memo'];
		
		$this->_payment_settings['button_url'] = isset( $_POST['button_url'] ) ? esc_url_raw( $_POST['button_url'] ) : '';

		
	}


	

	protected function _display_settings() {
		?>
		<tr>
			<th>
				<label><strong style="color:#F00"><?php _e('Please Note', 'event_espresso'); ?></strong></label>
			</th>
			<td>
				<?php _e('You will need a VoguePay Account to be able ton use this module <br/> Please visit  <a target="_blank" href="https://voguepay.com">VoguePay.com</a>.', 'event_espresso'); ?>
			</td>
		</tr>

		<tr>
			<th><label for="merchant_id">
					<?php _e('Merchant ID', 'event_espresso'); ?>
				</label></th>
			<td><input class="regular-text" type="text" name="v_merchant_id" size="35" id="merchant_id" value="<?php echo $this->_payment_settings['merchant_id']; ?>">
				<br />
				<span class="description">
					<?php _e('Your VoguePay Merchant ID', 'event_espresso'); ?>
				</span></td>
		</tr>

		<tr>
			<th><label for="memo">
					<?php _e('Memo', 'event_espresso'); ?>
				</label></th>
			<td><input class="regular-text" type="text" name="memo" size="35" id="memo" value="<?php echo $this->_payment_settings['memo']; ?>">
				<br />
				<span class="description">
					<?php _e('The transaction summary of what the customer is purchasing', 'event_espresso'); ?>
				</span></td>
		</tr>
		<?php
	}

	protected function _display_settings_help() {
		
	}

	public function process_payment_start(EE_Line_Item $total_line_item, $transaction = null,$total_to_pay = NULL) {

		$voguepay_settings = $this->_payment_settings;
		$merchant_id = $voguepay_settings['merchant_id'];		
		$memo = $voguepay_settings['memo'];		

		$item_num = 1;

		/* @var $transaction EE_Transaction */
		if( ! $transaction){
			$transaction = $total_line_item->transaction();
		}
		$primary_registrant = $transaction->primary_registration();
		if( $total_to_pay === NULL && //they didn't specify an amount to charge
			$total_to_pay != $transaction->total() && //and even if they did, it wasn't for the entire transaction
			! $transaction->paid()){//and there have been no payments on the transaction yet anyways
			//so let's create a nice looking invoice including everything
			foreach($total_line_item->get_items() as $line_item){
				$this->addField('item_1' . $item_num,
						substr(
								sprintf(
										__( '%s for %s', 'event_espresso' ),
										$line_item->name() ,
										$line_item->ticket_event_name() ),
								0,
								127 ) );
				$this->addField('price_1' . $item_num, $line_item->unit_price());
				$this->addField('quantity_' . $item_num, $line_item->quantity());
				$item_num++;
			}

			foreach ($total_line_item->tax_descendants() as  $tax_line_item) {
				$this->addField('item_1' . $item_num, substr($tax_line_item->name(),0,127));
				$this->addField('price_1' . $item_num, $tax_line_item->total());
				$this->addField('quantity_' . $item_num, '1');
				$item_num++;
			}
		}else{//we're only charging for part of the transaction's total
			if( $total_to_pay){
				//client code specified how much to charge
				$description = sprintf(__("Partial payment of %s", "event_espresso"),$total_to_pay);
			}elseif($transaction->paid()){
				//they didn't specify how much, but there has already been a payment, so let's just charge on what's left
				$total_to_pay = $transaction->remaining();
				$description = sprintf(__("Total paid to date: %s, and this charge is for the balance.", "event_espresso"),$transaction->get_pretty('TXN_paid'));
			}else{
				throw new EE_Error(sprintf(__("Thats impossible!!", "event_espresso")));
			}
			$this->addField('item_1'.$item_num,  sprintf(__("Amount owing for registration %s", 'event_espresso'),$primary_registrant->reg_code()));
			$this->addField('price_1'.$item_num,$total_to_pay);
			$this->addField('on0_'.$item_num,  __("Amount Owing:", 'event_espresso'));
			$this->addField('os0_'.$item_num,  $description);
			$item_num++;
		}

		
		$this->addField('v_merchant_id', $merchant_id);
		$this->addField('developer_code', '54913dc1a5189');
		$this->addField('success_url',  $this->_get_return_url($primary_registrant));
		$this->addField('fail_url', $this->_get_cancel_url());
		$this->addField('notify_url', $this->_get_notify_url($primary_registrant));
		$this->addField('cmd', '_cart');
		$this->addField('upload', '1');
		
		$this->addField('memo', $memo);
		
		$this->addField('bn', 'EventEspresso_SP');//EE will blow up if you change this
		do_action( 'AHEE_log', __FILE__, __FUNCTION__, serialize(get_object_vars($this)) );
		$this->_EEM_Gateways->set_off_site_form($this->submitPayment());

		$this->redirect_after_reg_step_3($transaction,$this->_gatewayUrl);
	}




	
	public function handle_ipn_for_transaction(EE_Transaction $transaction){
		$this->_debug_log("<hr><br>".get_class($this).":start handle_ipn_for_transaction on transaction:".($transaction instanceof EE_Transaction)?$transaction->ID():'unknown');

		//verify there's payment data that's been sent
		if(empty($_POST['transaction_id'])){
			return false;
		}
		$this->_debug_log( "<hr><br>".get_class($this).": payment_status and txn_id sent properly. payment_status:".$_POST['transaction_id']);

		//if the transaction's just an ID, swap it for a real EE_Transaction
		$transaction = $this->_TXN->ensure_is_obj($transaction);
		//verify the transaction exists
		if(empty($transaction)){
			return false;
		}

		if(isset($_POST['transaction_id']))
		{
			$transaction_id = $_POST['transaction_id'];

			$args = array( 'sslverify' => false );

			$json = wp_remote_get( 'https://voguepay.com/?v_transaction_id='.$transaction_id.'&type=json', $args );

			$v_transaction 	= json_decode($json['body'], true);
			$v_transaction_id = $v_transaction['transaction_id'];

			//ok, well let's process this payment then!
			if($v_transaction['status'] == 'Approved'){ //the old code considered 'Pending' as completed too..
				$status = EEM_Payment::status_id_approved;//approved
				$gateway_response = __('Your payment is approved.', 'event_espresso');
			}elseif($v_transaction['status']=='Pending'){
				$status = EEM_Payment::status_id_pending;//approved
				$gateway_response = __('Your payment is in progress. Another message will be sent when payment is approved.', 'event_espresso');
			}else{
				$status = EEM_Payment::status_id_declined;//declined
				$gateway_response = __('Your payment has been declined.', 'event_espresso');
			}
			$this->_debug_log( "<hr>Payment is interpreted as $status, and the gateway's response set to '$gateway_response'");
			//check if we've already processed this payment

			$payment = $this->_PAY->get_payment_by_txn_id_chq_nmbr($v_transaction_id);
			if(!empty($payment)){
				//payment exists. if this has the exact same status and amount, don't bother updating. just return
				if($payment->STS_ID() == $status && $payment->amount() == $v_transaction['total']){
					//echo "duplicated ipn! dont bother updating transaction foo!";
					$this->_debug_log( "<hr>Duplicated IPN! ignore it...");
					return false;
				}else{
					$this->_debug_log( "<hr>Existing Voguepay transaction, but it\'s got some new info. Old status:".$payment->STS_ID().", old amount:".$payment->amount());
					$payment->set_status($status);
					$payment->set_amount($v_transaction['total']);
					$payment->set_gateway_response($gateway_response);
					$payment->set_details($_POST);
				}
			}
			else{
				$this->_debug_log( "<hr>No Previous IPN payment received. Create a new one");
				//no previous payment exists, create one
				$primary_registrant = $transaction->primary_registration();
				$primary_registration_code = !empty($primary_registrant) ? $primary_registrant->reg_code() : '';

				$payment = EE_Payment::new_instance(array(
					'TXN_ID' => $transaction->ID(),
					'STS_ID' => $status,
					'PAY_timestamp' => current_time( 'mysql', FALSE ),					
					'PAY_amount' => floatval($v_transaction['total']),
					'PAY_gateway' => $this->_gateway_name,
					'PAY_gateway_response' => $gateway_response,
					'PAY_txn_id_chq_nmbr' => $transaction_id,					
					'PAY_extra_accntng'=>$primary_registration_code,
					'PAY_via_admin' => false,
					'PAY_details' => $_POST
				));

			}
		}

		$payment->save();
		return $this->update_transaction_with_payment($transaction,$payment);
	}




	public function espresso_display_payment_gateways( $selected_gateway = '' ) {
		$this->_css_class = $selected_gateway == $this->_gateway_name ? '' : ' hidden';
		echo $this->_generate_payment_gateway_selection_button();
		?>


		<div id="reg-page-billing-info-<?php echo $this->_gateway_name; ?>-dv" class="reg-page-billing-info-dv <?php echo $this->_css_class; ?>">
			<h3><?php _e('You have selected "Voguepay" as your method of payment', 'event_espresso'); ?></h3>
			<p><?php _e('After finalizing your registration, you will be transferred to the VoguePay website where your payment will be securely processed.', 'event_espresso'); ?></p>
		</div>

		<?php
	}

	

}

//end class
